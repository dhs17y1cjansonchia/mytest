roslaunch rubiker reset.launch
