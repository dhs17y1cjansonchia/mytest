cd ~/catkin_ws
catkin_make -j2 -l2 && source devel/setup.bash && echo "--- Sourced setup.bash ---"
